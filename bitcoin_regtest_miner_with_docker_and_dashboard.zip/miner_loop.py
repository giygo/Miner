import time
import hashlib
from segwit_addr import decode, convertbits

def address_to_scriptpubkey(address):
    if address.startswith('bc1') or address.startswith('tb1'):
        hrp, data = decode('bc', address)
        if data is None:
            raise ValueError("Invalid Bech32 address")
        witness_program = convertbits(data[1:], 5, 8, False)
        return bytes([0x00, len(witness_program)]) + bytes(witness_program)
    else:
        raise ValueError("Only Bech32 addresses supported in this version")

payout_address = "bc1qzsfv4gjzqgc8xn44v8xfdw8u4kl7ps8s4zygsx"
script_pubkey = address_to_scriptpubkey(payout_address)

base_data = b"fakeblockheader"  # This would be built from a real block template
target_prefix = "00000000"
nonce = 0

while True:
    nonce_bytes = nonce.to_bytes(4, 'big')
    combined = base_data + nonce_bytes
    hash_result = hashlib.sha256(combined).hexdigest()
    if hash_result.startswith(target_prefix):
        print(f"Block mined! Nonce: {nonce} Hash: {hash_result}")
        with open("dashboard_status.txt", "w") as f:
            f.write(f"Mined at nonce {nonce} with hash {hash_result}\n")
        break
    if nonce % 100000 == 0:
        with open("dashboard_status.txt", "w") as f:
            f.write(f"Searching... nonce={nonce} last hash={hash_result}\n")
    nonce += 1
    time.sleep(0.001)
