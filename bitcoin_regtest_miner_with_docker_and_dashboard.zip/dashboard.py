from flask import Flask
app = Flask(__name__)

@app.route("/")
def status():
    try:
        with open("dashboard_status.txt") as f:
            status = f.read()
    except FileNotFoundError:
        status = "Miner not running yet."
    return f"<h1>Bitcoin Miner Dashboard</h1><pre>{status}</pre>"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
