import segwit_addr

def address_to_scriptpubkey(address):
    if address.startswith('bc1') or address.startswith('tb1'):
        hrp, data = segwit_addr.decode('bc', address)
        if data is None:
            raise ValueError("Invalid Bech32 address")
        witness_program = segwit_addr.convertbits(data[1:], 5, 8, False)
        return bytes([0x00, len(witness_program)]) + bytes(witness_program)
    else:
        raise ValueError("Only Bech32 addresses supported in this version")

payout_address = "bc1qzsfv4gjzqgc8xn44v8xfdw8u4kl7ps8s4zygsx"
script_pubkey = address_to_scriptpubkey(payout_address)

print(f"ScriptPubKey for {payout_address}: {script_pubkey.hex()}")
