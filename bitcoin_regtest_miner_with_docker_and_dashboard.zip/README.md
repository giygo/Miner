# Bitcoin Regtest Miner

Now configured to use the real payout address.
