# Bitcoin Regtest Miner

Now supports payout to a Bech32 wallet address.
