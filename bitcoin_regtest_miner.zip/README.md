# 🪙 Bitcoin Regtest Miner with Dashboard (Dockerized)

This project is a fully containerized Bitcoin regtest miner with:
- A SHA-256 multiprocessing miner (Python)
- `bitcoind` in regtest mode
- A Flask dashboard to monitor blocks
- Telegram & email alert hooks (optional)

---

## 🚀 Quick Start

```bash
git clone https://your-repo-url
cd bitcoin_regtest_miner
docker-compose up --build
```

### Access Dashboard
Visit: [http://localhost:5000](http://localhost:5000)

---

## ⚙️ Configuration

Update `config.env`:

```env
RPC_USER=user
RPC_PASSWORD=pass
MINER_ADDRESS=bcrt1qzsfv4gjzqgc8xn44v8xfdw8u4kl7ps8s4zygsx

# Optional Telegram alerts
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here

# Optional Email alerts
EMAIL_HOST=smtp.example.com
EMAIL_PORT=587
EMAIL_USER=example@example.com
EMAIL_PASSWORD=yourpassword
EMAIL_RECIPIENT=recipient@example.com
```

---

## 🛠️ Miner Details

- Uses Python `multiprocessing` to brute-force a SHA-256 block hash
- Automatically builds a block with coinbase + (optional) custom TXs from local UTXOs
- Uses `getblocktemplate` / `submitblock` to mine new blocks
- Compatible with regtest only (testnet support optional)

---

## 📦 Included Services

| Service    | Port   | Description                |
|------------|--------|----------------------------|
| bitcoind   | 18443  | Bitcoin Core (regtest)     |
| miner      | N/A    | Custom Python miner        |
| dashboard  | 5000   | Web UI for monitoring      |

---

## 🔐 Wallet Tips

To generate a payout address in `bitcoind`:

```bash
docker exec -it <bitcoind_container> bitcoin-cli -regtest getnewaddress
docker exec -it <bitcoind_container> bitcoin-cli -regtest dumpprivkey <address>
```

Paste the address into `config.env` as `MINER_ADDRESS`.

---

## 📲 Telegram & Email Alerts (optional)

To enable alerts:
- Set your Telegram bot token and chat ID in `config.env`
- Or configure SMTP email credentials

You can integrate those into `miner_full.py` (hooks already scaffolded).

---

## 🧹 Reset Regtest Chain

```bash
docker-compose down -v
```

---

## 🧠 Built With

- Python 3.11
- [python-bitcoinlib](https://github.com/petertodd/python-bitcoinlib)
- Flask
- Docker & Compose