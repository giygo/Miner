#!/bin/bash
echo "✅ Starting test run (regtest miner)..."

echo "➡️  Mining 1 block..."
docker-compose exec miner python miner_full.py & sleep 5

echo "➡️  Checking dashboard..."
curl http://localhost:5000

echo "➡️  Done. Check logs with: docker-compose logs miner"