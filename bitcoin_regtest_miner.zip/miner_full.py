import os
import time
import struct
import hashlib
import multiprocessing
import requests
from base64 import b64encode
from bitcoin.core import COIN, lx, b2lx, COutPoint, CMutableTxIn, CMutableTxOut, CMutableTransaction, CScript
from bitcoin.wallet import CBitcoinSecret, P2PKHBitcoinAddress
from bitcoin.core.script import OP_DUP, OP_HASH160, OP_EQUALVERIFY, OP_CHECKSIG, SignatureHash, SIGHASH_ALL
from bitcoin import SelectParams

SelectParams("regtest")

RPC_USER = os.getenv("RPC_USER", "user")
RPC_PASSWORD = os.getenv("RPC_PASSWORD", "pass")
RPC_PORT = int(os.getenv("RPC_PORT", 18443))
MINER_ADDRESS = os.getenv("MINER_ADDRESS", "bcrt1...")

def rpc(method, params=None):
    body = {"jsonrpc": "1.0", "id": "miner", "method": method, "params": params or []}
    auth = b64encode(f"{RPC_USER}:{RPC_PASSWORD}".encode()).decode()
    r = requests.post(f"http://127.0.0.1:{RPC_PORT}", json=body, headers={"Authorization": f"Basic {auth}"})
    r.raise_for_status()
    result = r.json()
    if result.get("error"):
        raise Exception(result["error"])
    return result["result"]

def double_sha256(b): return hashlib.sha256(hashlib.sha256(b).digest()).digest()

def create_coinbase_tx(to_addr, height):
    script_sig = CScript([height])
    txin = CMutableTxIn(COutPoint(0, 0xffffffff), script_sig, 0xffffffff)
    out = CMutableTxOut(50 * COIN, P2PKHBitcoinAddress(to_addr).to_scriptPubKey())
    tx = CMutableTransaction([txin], [out])
    return tx.serialize()

def get_merkle_root(tx_list):
    hashes = [double_sha256(tx) for tx in tx_list]
    while len(hashes) > 1:
        if len(hashes) % 2: hashes.append(hashes[-1])
        hashes = [double_sha256(hashes[i] + hashes[i+1]) for i in range(0, len(hashes), 2)]
    return hashes[0][::-1].hex()

def build_header(template, merkle, nonce):
    v = struct.pack("<I", template["version"])
    prev = bytes.fromhex(template["previousblockhash"])[::-1]
    merkle = bytes.fromhex(merkle)[::-1]
    t = struct.pack("<I", template["curtime"])
    bits = bytes.fromhex(template["bits"])
    n = struct.pack("<I", nonce)
    return v + prev + merkle + t + bits + n

def mine(header_prefix, target, queue, start, step):
    tgt = int(target, 16)
    for nonce in range(start, 0xffffffff, step):
        hdr = header_prefix + struct.pack("<I", nonce)
        if int.from_bytes(double_sha256(hdr)[::-1], "big") < tgt:
            queue.put((nonce, hdr))
            return

def get_utxo():
    for utxo in rpc("listunspent"):
        if utxo["spendable"] and utxo["amount"] > 0.0001:
            return utxo
    raise Exception("No spendable UTXO")

def sign_tx(wif, utxo, to_address, fee_sat=1000):
    seckey = CBitcoinSecret(wif)
    from_addr = P2PKHBitcoinAddress.from_pubkey(seckey.pub)
    txin = CMutableTxIn(COutPoint(lx(utxo["txid"]), utxo["vout"]))
    send_val = int(utxo["amount"] * 1e8) - fee_sat
    out = CMutableTxOut(send_val, P2PKHBitcoinAddress(to_address).to_scriptPubKey())
    tx = CMutableTransaction([txin], [out])
    script_pubkey = CScript([OP_DUP, OP_HASH160, from_addr, OP_EQUALVERIFY, OP_CHECKSIG])
    sighash = SignatureHash(script_pubkey, tx, 0, SIGHASH_ALL)
    sig = seckey.sign(sighash) + bytes([SIGHASH_ALL])
    txin.scriptSig = CScript([sig, seckey.pub])
    return tx.serialize()

def main():
    while True:
        tpl = rpc("getblocktemplate")
        height = tpl["height"]
        coinbase = create_coinbase_tx(MINER_ADDRESS, height)
        txs = [coinbase]
        try:
            utxo = get_utxo()
            wif = rpc("dumpprivkey", [utxo["address"]])
            tx = sign_tx(wif, utxo, MINER_ADDRESS)
            txs.append(tx)
        except Exception as e:
            print("TX failed:", e)
        merkle = get_merkle_root(txs)
        prefix = build_header(tpl, merkle, 0)[:-4]
        target = tpl["target"]
        q = multiprocessing.Queue()
        workers = []
        for i in range(multiprocessing.cpu_count()):
            p = multiprocessing.Process(target=mine, args=(prefix, target, q, i, multiprocessing.cpu_count()))
            p.start()
            workers.append(p)
        nonce, header = q.get()
        for p in workers: p.terminate()
        block_hex = header.hex() + "".join(tx.hex() for tx in txs)
        res = rpc("submitblock", [block_hex])
        print("Block submitted:", res or "OK")
        time.sleep(0.2)

if __name__ == "__main__":
    main()