# Flask/FastAPI dashboard init
